# LocalOpenHands with Qwen3-8B

This is a modified version of [OpenHands](https://github.com/All-Hands-AI/OpenHands) that runs completely locally, using the [Qwen3-8B](https://huggingface.co/Qwen/Qwen3-8B) model from Hugging Face. It doesn't depend on any external services or API keys.

## Features

- **100% Local**: No external API calls or dependencies on cloud services
- **Free to Use**: Uses open-source models and software
- **CPU Compatible**: Designed to work on systems without GPU acceleration
- **Easy Setup**: Simple installation process with robust error handling
- **Docker Support**: Optional containerized deployment for easier management
- **Same Functionality**: Maintains all the capabilities of the original OpenHands

## System Requirements

- **CPU**: Modern multi-core CPU (4+ cores recommended)
- **RAM**: Minimum 8GB, 16GB+ recommended
- **Disk Space**: At least 15GB free space
- **Operating System**: Linux, macOS, or Windows with WSL
- **Software**: Python 3.8+, Git, Make

## Installation

### Option 1: Automated Installation (Recommended)

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/LocalOpenHands.git
   cd LocalOpenHands
   ```

2. Run the robust installation script:
   ```bash
   ./install_robust.sh
   ```

   This script will:
   - Check system requirements
   - Install required dependencies
   - Download and convert the Qwen3-8B model
   - Configure OpenHands to use the local model
   - Test the setup to ensure everything works

### Option 2: Docker Compose

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/LocalOpenHands.git
   cd LocalOpenHands
   ```

2. Make sure Docker and Docker Compose are installed.

3. Start the containers:
   ```bash
   docker-compose -f docker-compose.local.robust.yml up -d
   ```

### Option 3: Manual Setup

If you prefer to set up each component manually:

1. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Download and convert the model:
   ```bash
   python scripts/download_and_convert_qwen_robust.py
   ```

3. Start the llama.cpp server:
   ```bash
   python scripts/run_llama_cpp_server_robust.py
   ```

4. In a separate terminal, start OpenHands:
   ```bash
   make run
   ```

## Usage

### Starting LocalOpenHands

#### Automated Method (Recommended)

Run the following command:
```bash
./run_local_openhands_robust.sh
```

This script will:
- Start the local model server
- Start OpenHands
- Monitor both services and restart them if they crash

#### Docker Method

If you installed using Docker, the services should already be running. If not, start them with:
```bash
docker-compose -f docker-compose.local.robust.yml up -d
```

### Accessing the Interface

Once started, access OpenHands in your web browser at:
```
http://localhost:3000
```

## Architecture

LocalOpenHands consists of two main components:

1. **Local Model Server**: A [llama.cpp](https://github.com/ggerganov/llama.cpp) server that hosts the Qwen3-8B model and provides an OpenAI-compatible API.

2. **OpenHands Application**: The original OpenHands software, configured to use the local model server instead of external APIs.

## Configuration

The configuration is stored in `config.toml`. You can modify this file to change settings such as:

- Model parameters (temperature, max tokens, etc.)
- Workspace location
- Agent settings

## Limitations

- Function calling may not work as well as with commercial models
- Performance is slower than with GPU acceleration
- Some advanced features may not be available

## Troubleshooting

### Model Server Issues

If the model server fails to start:

1. Check if you have enough RAM available
2. Verify that the model file exists at `models/gguf/qwen3-8b-q4_0.gguf`
3. Try running the server manually:
   ```bash
   python scripts/run_llama_cpp_server_robust.py
   ```

### OpenHands Issues

If OpenHands fails to start:

1. Make sure the model server is running
2. Check the OpenHands logs for errors
3. Verify that the configuration in `config.toml` is correct

### Model Download Issues

If the model download fails:

1. Check your internet connection
2. Try the alternative download method in the installation script
3. You can manually download the model from Hugging Face and convert it using:
   ```bash
   python scripts/download_and_convert_qwen_robust.py
   ```

### Memory Issues

If you encounter memory issues:
- Try reducing the context size in `scripts/run_llama_cpp_server_robust.py` by changing the `n_ctx` parameter
- Close other memory-intensive applications
- Consider using a machine with more RAM

### Slow Performance

This setup runs on CPU only. Performance will be slower than with a GPU. To improve performance:
- Increase the number of threads in `scripts/run_llama_cpp_server_robust.py` if you have more CPU cores
- Use a more powerful CPU
- Consider using a quantized model with lower precision (e.g., q2_K) for faster inference at the cost of quality

## Advanced Configuration

### Customizing Model Parameters

You can adjust the model parameters in `scripts/run_llama_cpp_server_robust.py`:

- `n_ctx`: Context window size (default: 4096)
- `n_threads`: Number of CPU threads to use (default: 4)
- `n_batch`: Batch size for inference (default: 512)

### Using a Different Model

To use a different model:

1. Download and convert the model to GGUF format
2. Update the model path in the configuration files
3. Update the model parameters in the server scripts

## Verification

To verify that your installation is working correctly, run:

```bash
python scripts/verify_installation.py
```

This script will check all components of the system and ensure they're working together correctly.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [OpenHands](https://github.com/All-Hands-AI/OpenHands) for the original project
- [Qwen](https://huggingface.co/Qwen) for the Qwen3-8B model
- [llama.cpp](https://github.com/ggerganov/llama.cpp) for the efficient CPU inference